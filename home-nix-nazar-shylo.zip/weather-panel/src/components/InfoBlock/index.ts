import { InfoBlock } from './InfoBlock';

export { InfoBlock };
